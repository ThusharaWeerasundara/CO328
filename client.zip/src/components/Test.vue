<template>
  <div >
     <video-background
    src="./test.mp4"
    style="max-height: 400px; height: 100vh;"
 >

 </video-background>
 <h1 style="color: black;">Hello welcome!</h1>
</div>

</template>
